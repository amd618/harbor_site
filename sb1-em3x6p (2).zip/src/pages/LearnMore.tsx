import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import IncomeChart from '../components/IncomeChart';
import LineChart from '../components/LineChart';
import StatsSection from '../components/StatsSection';
import LogoSection from '../components/LogoSection';
import GraduatesSection from '../components/GraduatesSection';
import PlanSection from '../components/PlanSection';
import CriteriaSection from '../components/CriteriaSection';
import Footer from '../components/Footer';

export default function LearnMore() {
  const [view, setView] = useState('problem');

  return (
    <div className="min-h-screen bg-black overflow-x-hidden pt-32 text-center">
      <div className="flex justify-center items-center py-6 mb-8">
        <div className="relative flex items-center bg-white/10 rounded-xl p-1 w-[400px]">
          <motion.div
            className="absolute h-full top-0 rounded-lg bg-[#1e90ff]"
            initial={false}
            animate={{
              x: view === 'problem' ? 0 : '100%',
              width: '50%'
            }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          />
          
          <div 
            onClick={() => setView('problem')}
            className={`relative px-8 py-2 cursor-pointer text-lg transition-colors duration-200 z-10 flex-1 text-center ${
              view === 'problem' ? 'text-white' : 'text-white/60 hover:text-white/80'
            }`}
          >
            The Challenge
          </div>
          <div 
            onClick={() => setView('solution')}
            className={`relative px-8 py-2 cursor-pointer text-lg transition-colors duration-200 z-10 flex-1 text-center ${
              view === 'solution' ? 'text-white' : 'text-white/60 hover:text-white/80'
            }`}
          >
            Vision
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {view === 'problem' ? (
          <motion.div
            key="problem"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="text-center space-y-32"
          >
            <div className="min-h-[60vh] flex items-center justify-center">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div 
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="space-y-16 text-center"
                >
                  <h1 className="text-5xl md:text-7xl font-medium text-white">
                    Southwest Virginia is <span className="text-[#1e90ff]">behind</span>
                  </h1>
                  <p className="text-2xl md:text-4xl text-white max-w-5xl mx-auto">
                    The I-81 corridor is lagging the rest of Virginia
                  </p>
                </motion.div>
              </div>
            </div>

            <div className="flex items-center justify-center min-h-[60vh]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div 
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="space-y-16 text-center"
                >
                  <h2 className="text-4xl md:text-6xl font-medium text-white">
                    Lower Income Levels
                  </h2>
                  <p className="text-xl md:text-2xl text-white max-w-3xl mx-auto">
                    Southwest Virginia's median household income is 35% below the Virginia state average
                  </p>
                  <IncomeChart />
                </motion.div>
              </div>
            </div>

            <div className="flex items-center justify-center min-h-[60vh]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div 
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="space-y-16 text-center"
                >
                  <h2 className="text-4xl md:text-6xl font-medium text-white">
                    Decelerating Growth
                  </h2>
                  <p className="text-xl md:text-2xl text-white max-w-3xl mx-auto">
                    This region is growing 44% slower than the rest of Virginia
                  </p>
                  <LineChart />
                </motion.div>
              </div>
            </div>

            <StatsSection />
            <LogoSection />
            <GraduatesSection />
            <Footer />
          </motion.div>
        ) : (
          <motion.div
            key="solution"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="text-center space-y-48"
          >
            <div className="min-h-[60vh] flex items-center justify-center">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-5xl md:text-7xl font-medium text-white mb-8">
                  Vision
                </h1>
                <p className="text-2xl md:text-4xl text-white max-w-5xl mx-auto">
                  To build a portfolio of businesses across industries, that generate consistent returns, attract top talent, and serve as a regional anchor for sustainable growth and prosperity.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-center pt-24">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-4xl md:text-6xl font-medium text-white mb-8">
                  The Plan
                </h2>
                <PlanSection />
              </div>
            </div>

            <div className="flex items-center justify-center pt-48">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-4xl md:text-6xl font-medium text-white mb-8">
                  Deal Criteria
                </h2>
                <CriteriaSection />
              </div>
            </div>

            <div className="flex items-center justify-center py-16">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-4xl md:text-6xl font-medium text-white mb-8">Learn More</h2>
                <a 
                  href="mailto:connect@harbor.capital"
                  className="text-2xl text-[#1e90ff] hover:text-[#1e90ff]/80 transition-colors"
                >
                  connect@harbor.capital
                </a>
              </div>
            </div>

            <Footer />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}