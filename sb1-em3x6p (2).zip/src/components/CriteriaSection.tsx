import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Briefcase, TrendingUp, PieChart, DollarSign } from 'lucide-react';

const criteria = [
  {
    icon: Briefcase,
    title: "Industry Agnostic",
    description: "Harbor evaluates assets across all industries, focusing on fundamentals rather than specific sectors. This allows us to identify exceptional businesses anywhere.",
    color: "#1e90ff"
  },
  {
    icon: TrendingUp,
    title: "Growth Trajectory",
    description: "Target companies must demonstrate a 15% annual growth rate, showing strong market position and potential for continued expansion.",
    color: "#34d399"
  },
  {
    icon: PieChart,
    title: "Profit Margins",
    description: "We look for businesses with proven profitability, maintaining margins above 10% to ensure sustainable operations, growth capital and returns.",
    color: "#8b5cf6"
  },
  {
    icon: DollarSign,
    title: "Cash Flow",
    description: "Our sweet spot is companies generating between $500,000 and $5 million in annual cash flow, providing a solid foundation for the future.",
    color: "#f59e0b"
  }
];

export default function CriteriaSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -50 },
    visible: { opacity: 1, x: 0 }
  };

  return (
    <motion.div
      ref={ref}
      variants={containerVariants}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      className="flex flex-col space-y-4 max-w-4xl mx-auto mt-16"
    >
      {criteria.map((item, index) => {
        const Icon = item.icon;
        return (
          <motion.div
            key={item.title}
            variants={itemVariants}
            transition={{ 
              duration: 0.8,
              type: "spring",
              stiffness: 100,
              damping: 12
            }}
            whileHover={{ 
              scale: 1.02,
              transition: { duration: 0.2 }
            }}
            className="bg-black/30 backdrop-blur-sm p-8 rounded-xl border border-white/10 hover:border-white/20 transition-all"
          >
            <div className="flex items-start space-x-6">
              <motion.div 
                className="p-4 rounded-lg shrink-0"
                style={{ backgroundColor: `${item.color}20` }}
                whileHover={{
                  backgroundColor: `${item.color}30`,
                  scale: 1.1,
                  rotate: 10
                }}
              >
                <Icon size={32} style={{ color: item.color }} />
              </motion.div>
              <div>
                <motion.h3 
                  className="text-2xl font-medium text-white mb-2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 * index }}
                >
                  {item.title}
                </motion.h3>
                <motion.p 
                  className="text-white/80 text-lg leading-relaxed"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 * index }}
                >
                  {item.description}
                </motion.p>
              </div>
            </div>
          </motion.div>
        );
      })}
    </motion.div>
  );
}