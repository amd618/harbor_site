import React from 'react';
import { motion } from 'framer-motion';
import { Mail, MapPin, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black/50 backdrop-blur-sm mt-32 py-16 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="text-center md:text-left">
            <h3 className="text-white text-lg font-medium mb-4">Contact</h3>
            <div className="space-y-4">
              <div className="flex items-center text-white/70 justify-center md:justify-start">
                <Mail className="h-5 w-5 mr-2" />
                <a href="mailto:connect@harbor.capital" className="hover:text-white transition-colors">
                  connect@harbor.capital
                </a>
              </div>
              <div className="flex items-center text-white/70 justify-center md:justify-start">
                <MapPin className="h-5 w-5 mr-2" />
                <span>Roanoke, VA</span>
              </div>
            </div>
          </div>

          <div className="text-center md:text-left">
            <h3 className="text-white text-lg font-medium mb-4">Legal</h3>
            <div className="space-y-2 text-white/70">
              <p>© {new Date().getFullYear()} Harbor Capital Partners, LLC.</p>
              <p>All rights reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}